# Typescript-desafio2
Typescript Desafio 2
